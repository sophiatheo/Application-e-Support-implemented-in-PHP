<?php
include ("controller/control.php");
 

?>