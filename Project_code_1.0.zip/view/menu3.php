<nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <a class="navbar-brand" href="<?php echo $dir; ?>/">SupportCI</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="<?php echo $dir; ?>/emp">Home</a></li>
      <li><a href="<?php echo $dir; ?>/admin">Login as Admin</a></li>
      <li><a href="<?php echo $dir; ?>/">Login as Customer</a></li>
     
    </ul>
  </div>
</nav>