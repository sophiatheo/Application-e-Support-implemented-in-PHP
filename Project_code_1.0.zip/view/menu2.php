<nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <a class="navbar-brand" href="<?php echo $dir; ?>/">SupportCI</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="<?php echo $dir; ?>/admin">Home</a></li>
      <li><a href="<?php echo $dir; ?>/">Login as Customer</a></li>
      <li><a href="<?php echo $dir; ?>/emp">Login as Employeer</a></li>
     
    </ul>
  </div>
</nav>