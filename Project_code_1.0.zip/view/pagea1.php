<div class="col-md-4">
<form id=frm2a>
  <h1>Administrator</h1>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email" name='email'>
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd" name='pwd'>
  </div> 
 
  <button type="submit" class="btn btn-default">Submit</button>
</form>

<div id="msg">

</div>
</div>