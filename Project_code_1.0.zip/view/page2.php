<form  id=frm1>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email" name=email>
  </div> 
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd" name=pwd>
  </div>
<div class="form-group">
    <label for="fn">Fullname:</label>
    <input type="text" class="form-control" id="fn" name=fn>
  </div>
  <div class="form-group">
    <label for="ph">Phone:</label>
    <input type="text" class="form-control" id="ph" name=ph>
  </div>
  <div class="form-group">
    <label for="addr">Address:</label>
    <input type="text" class="form-control" id="addr" name=addr>
  </div>
  <div class="form-group">
    <label for="city">City:</label>
    <input type="text" class="form-control" id="city" name=city>
  </div>
  <button type="submit" class="btn btn-default">Sign Up</button>
</form>

<div id=msg>

</div>