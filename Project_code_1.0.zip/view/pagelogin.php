
 
<div class="jumbotron text-center">
  <h1>Wellcome</h1>
  <p>Your Main Page</p> 
</div>
 

