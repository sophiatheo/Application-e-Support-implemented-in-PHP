<div class=container>
	<div class=row >
		<div class=col-md-2></div>
		<div class=col-md-6>
			<table id=list class=table>
			<tr><th>Email</th><th>Fullname</th><th>Action</th></tr>
			<tbody id=list>
			
			</tbody>
			</table> 
		</div>

	</div>
</div>
<script>
	getUsers();
	
</script>