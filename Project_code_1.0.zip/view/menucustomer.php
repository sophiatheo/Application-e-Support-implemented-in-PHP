<nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li ><a href="<?php echo $dir; ?>/loginuser">Home</a></li>
      <li><a href="<?php echo $dir; ?>/newmessage">New Message</a></li>
	   <li><a href="<?php echo $dir; ?>/umessages">History Messages</a></li>
	   <li><a href="<?php echo $dir; ?>/profileu">Profile</a></li>
      <li><a href="<?php echo $dir; ?>/logout">Logout</a></li>
     
    </ul>
  </div>
</nav>