<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li ><a href="<?php echo $dir; ?>/loginadmin">Home</a></li>
      <li><a href="<?php echo $dir; ?>/userlist">Users</a></li>
	   <li><a href="<?php echo $dir; ?>/allmessages">Messages</a></li>
	   <li><a href="<?php echo $dir; ?>/profilea">Profile</a></li>
      <li><a href="<?php echo $dir; ?>/logout">Logout</a></li>
    
    </ul> 
  </div>
</nav>