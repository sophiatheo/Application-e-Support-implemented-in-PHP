<?php
$GLOBALS['server']="localhost";
$GLOBALS['userdb']="root";
$GLOBALS['pssdb']="";
$GLOBALS['database']="synomilies";
 


?>